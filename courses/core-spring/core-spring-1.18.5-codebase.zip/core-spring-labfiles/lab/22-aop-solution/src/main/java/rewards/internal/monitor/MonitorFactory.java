package rewards.internal.monitor;

public interface MonitorFactory {

	Monitor start(String name);
}
