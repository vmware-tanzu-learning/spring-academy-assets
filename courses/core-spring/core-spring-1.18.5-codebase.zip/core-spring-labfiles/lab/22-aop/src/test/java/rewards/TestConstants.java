package rewards;

public class TestConstants {
	
	// TODO-00: In this lab, you are going to exercise the following:
	// - Creating aspect using Spring AOP
	// - Writing pointcut expressions
	// - Using various types of advices
	//
	// TODO-01: Enable checking of console output in our Tests.
	// - Change the value below to true
	
	public static final boolean CHECK_CONSOLE_OUTPUT = false;
}
